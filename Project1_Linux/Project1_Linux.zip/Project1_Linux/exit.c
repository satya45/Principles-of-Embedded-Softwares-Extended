/**
* @brief EXIT the application
*
* @author Satya Mehta and Siddhant Jajoo
*/




#include <stdio.h>
#include "exit.h"
#include "main.h"


/*exit function*/
void ex(void)
{
e=0;
}
