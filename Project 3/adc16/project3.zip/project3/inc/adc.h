#include "MKL25Z4.h"
void adc_init();
uint16_t adc_read(uint8_t);
