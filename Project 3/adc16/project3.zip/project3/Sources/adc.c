#include "adc.h"
#include <stdint.h>


/*adc_init function Initializes ADC*/


void adc_init(void)
{
	/*Enable ADC Clock gates*/
	SIM_SCGC6 |= SIM_SCGC6_ADC0_MASK;
	SIM_SCGC5 |= SIM_SCGC5_PORTE_MASK;	// PortE clock


	/*Configuration of ADC*/
	ADC0_CFG1 |= ADC_CFG1_MODE(3) | ADC_CFG1_ADICLK(0) | ADC_CFG1_ADIV(1);
	ADC0_SC3=0;
	ADC0_SC1A |= ADC_SC1_DIFF(1)| ADC_SC1_AIEN(0);


	ADC0_SC1A |= ADC_SC1_ADCH(31);

	ADC0_RA;

}

uint16_t adc_read(uint8_t ch)

{
	ADC0_SC1A = ch & ADC_SC1_ADCH_MASK; //Write to SC1A to start conversion
	while(ADC0_SC2 & ADC_SC2_ADACT_MASK); 	 // Conversion in progress
	while(!(ADC0_SC1A & ADC_SC1_COCO_MASK)); // Run until the conversion is complete
	return ADC0_RA;

}
