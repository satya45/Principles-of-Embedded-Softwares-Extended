 #include "stdio.h"
#include "MKL25Z4.h"

void SysTick_config();
uint32_t startVal = 0;
uint32_t endVal = 0;
double dif=0;
